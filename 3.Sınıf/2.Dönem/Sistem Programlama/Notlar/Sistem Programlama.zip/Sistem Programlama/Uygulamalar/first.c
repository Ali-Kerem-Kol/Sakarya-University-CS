#include <stdio.h>

int main(){
    printf("Sistem Programlama\n");
    
    return 0;
}