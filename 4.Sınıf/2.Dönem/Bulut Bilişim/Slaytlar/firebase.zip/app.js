import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
  getFirestore,
  collection,
  addDoc,
  query,
  where,
  getDocs,
  serverTimestamp,
  updateDoc,
  deleteDoc,
  doc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "BURAYA_API_KEY",
  authDomain: "BURAYA_AUTH_DOMAIN",
  projectId: "BURAYA_PROJECT_ID",
  storageBucket: "BURAYA_STORAGE_BUCKET",
  messagingSenderId: "BURAYA_MESSAGING_SENDER_ID",
  appId: "BURAYA_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const registerBtn = document.getElementById("registerBtn");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");
const authMessage = document.getElementById("authMessage");

const authBox = document.getElementById("authBox");
const todoBox = document.getElementById("todoBox");
const userEmail = document.getElementById("userEmail");

const todoInput = document.getElementById("todoInput");
const addTodoBtn = document.getElementById("addTodoBtn");
const todoList = document.getElementById("todoList");

// KAYIT
registerBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    authMessage.textContent = "Kayıt başarılı: " + userCredential.user.email;
  } catch (error) {
    authMessage.textContent = "Kayıt hatası: " + error.message;
  }
});

// GİRİŞ
loginBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    authMessage.textContent = "Giriş başarılı: " + userCredential.user.email;
  } catch (error) {
    authMessage.textContent = "Giriş hatası: " + error.message;
  }
});

// ÇIKIŞ
logoutBtn.addEventListener("click", async () => {
  await signOut(auth);
});

// OTURUM TAKİBİ
onAuthStateChanged(auth, async (user) => {
  if (user) {
    authBox.classList.add("hidden");
    todoBox.classList.remove("hidden");
    userEmail.textContent = user.email;
    await loadTodos(user.uid);
  } else {
    authBox.classList.remove("hidden");
    todoBox.classList.add("hidden");
    todoList.innerHTML = "";
    userEmail.textContent = "";
  }
});

// TODO EKLE
addTodoBtn.addEventListener("click", async () => {
  const user = auth.currentUser;
  const text = todoInput.value.trim();

  if (!user) {
    alert("Önce giriş yapmalısınız.");
    return;
  }

  if (!text) {
    alert("Boş görev eklenemez.");
    return;
  }

  try {
    await addDoc(collection(db, "todos"), {
      text: text,
      uid: user.uid,
      email: user.email,
      done: false,
      createdAt: serverTimestamp()
    });

    todoInput.value = "";
    await loadTodos(user.uid);
  } catch (error) {
    alert("Todo ekleme hatası: " + error.message);
  }
});

// TODO'LARI YÜKLE
async function loadTodos(uid) {
  todoList.innerHTML = "";

  const q = query(
    collection(db, "todos"),
    where("uid", "==", uid)
  );

  const querySnapshot = await getDocs(q);

  querySnapshot.forEach((docSnap) => {
    const data = docSnap.data();

    const li = document.createElement("li");
    li.style.display = "flex";
    li.style.alignItems = "center";
    li.style.gap = "10px";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = !!data.done;

    const textSpan = document.createElement("span");
    textSpan.textContent = data.text;

    if (data.done) {
      textSpan.style.textDecoration = "line-through";
      textSpan.style.opacity = "0.6";
    }

    const statusBtn = document.createElement("button");
    statusBtn.textContent = data.done ? "Yapılmadı" : "Yapıldı";

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Sil";

    checkbox.addEventListener("change", async () => {
      await updateDoc(doc(db, "todos", docSnap.id), {
        done: checkbox.checked
      });
      await loadTodos(uid);
    });

    statusBtn.addEventListener("click", async () => {
      await updateDoc(doc(db, "todos", docSnap.id), {
        done: !data.done
      });
      await loadTodos(uid);
    });

    deleteBtn.addEventListener("click", async () => {
      await deleteDoc(doc(db, "todos", docSnap.id));
      await loadTodos(uid);
    });

    li.appendChild(checkbox);
    li.appendChild(textSpan);
    li.appendChild(statusBtn);
    li.appendChild(deleteBtn);

    todoList.appendChild(li);
  });
}